var deviceId = "4b94f90c-8946-46cf-b2d9-3d598f58f4b1";
var token = "d912f6c1673acea6cbfe62bb52a6aa2"; 
var msgIdColor = "6ba4a78190971f646dd0";
var msgIdButton= "4a56c4c8a304895f3ed1";
var msgIdTemp  = "fbf9c0ac6c3089c39e0a";

var iotMmsDestName = "iot_mms";

function createIOTTableChart(args) {
    var chart, sensorDataUrl;
    
	function updateChart() {
        var oModel = new sap.ui.model.json.JSONModel();
        oModel.loadData(sensorDataUrl, null, false);
	    chart.setModel(oModel);
	}
	
	function getChartForMetric(bindingName, minValue, maxValue){
	    var oChart = new sap.makit.Chart({
		    height: "300px",
		    width : "800px",
		    type: sap.makit.ChartType.Line,
		    category : new sap.makit.Category({ column : "G_CREATED" }),
		    categoryAxis : new sap.makit.CategoryAxis({ displayLastLabel: true}),
		    valueAxis    : new sap.makit.ValueAxis({  min:minValue, max:maxValue}),
		    values      :  [new sap.makit.Value({ expression : args.tableField, displayName : "C"})]
	    });
	
	    oChart.addColumn(new sap.makit.Column({name:"G_CREATED", value:"{G_CREATED}", type:"datetime"}));
	    oChart.addColumn(new sap.makit.Column({name:args.tableField, value:"{" +args.tableField + "}", type:"number"}));
	    oChart.bindRows(bindingName);
	
	    return oChart;
	}	
	
	function init() {
	    sensorDataUrl = "/" + args.iotMmsDest + "/v1/api/http/app.svc/T_IOT_" + args.messageId.toUpperCase() + 
	                    "?$orderby=G_CREATED desc&$top=100&$format=json&$filter=G_DEVICE%20eq%20%27" +
	                    args.deviceId.toLowerCase() + "%27";
		args.updateIntervalSec = args.updateIntervalSec || 15;
		chart = getChartForMetric("/d/results", 15, 35);
		setInterval(updateChart, args.updateIntervalSec * 1000);
		updateChart();
	}

	init();
	return chart;
}

function createIOTColorPicker(args) {
	function pushMessage(data) {
	   jQuery.ajax({
	        type : "POST",
	        async: false, 
	        processData: false,
	        contentType: "application/json;charset=UTF-8",
	        url : "/" + args.iotMmsDest + "/v1/api/http/push/" +args.deviceId.toLowerCase(),
	        data: JSON.stringify({method:"http", sender:"dkom test app", messageType:args.messageId, messages:[data]}),
	        success : function(data,textStatus, jqXHR) {sap.ui.commons.MessageBox.alert("Message pushed successfully to device!");},
	        error   : function(data,textStatus, jqXHR) {sap.ui.commons.MessageBox.alert("ERROR: Failed to push message! " + textStatus);}
	    });
	}
	
  	var panel = new sap.m.Panel({headerText:"Change the LED color of the dkom.Thing"});
  	var colorPicker = new sap.ui.commons.ColorPicker();
  	var button = new sap.ui.commons.Button({
		text : "Send Color",
		press : function() {
			var rgb = colorPicker.getRGB();
			var color = "0x" + ((rgb.r << 16) + (rgb.g << 8) + (rgb.b)).toString(16);
			var res = pushMessage({color:color});
		}
  	}); 
  	
  	panel.addContent(colorPicker);
  	panel.addContent(button);
  	
  	return panel;
}

function startThingButtonWatch(args) {
	var prevMsgCount = -1;
	function checkButton() {
	    function onSuccess(msgCount) {
			if (msgCount > -1 && prevMsgCount == -1) {prevMsgCount = msgCount;}
			if (msgCount > prevMsgCount) {
				args.onClick(msgCount - prevMsgCount);
				prevMsgCount = msgCount; 
			}
	    }
	    jQuery.ajax({ type : "GET", 
	                  async: false, 
	                  success: onSuccess,
	                  url : "/" + args.iotMmsDest + "/v1/api/http/app.svc/T_IOT_" + args.messageId.toUpperCase() + "/$count"
	    		   });
	}
	setInterval(checkButton, 3000);
	checkButton();
}

function buildUI() {
	var idPageMain = "main";
    // Now create the page and place it into the HTML document
    var mainPage = new sap.m.Page(idPageMain, {
        title : "D.Kom Sofia - IOT Test App",
        showNavButton : false
    });



    var colorPicker = createIOTColorPicker({
    	messageId: msgIdColor,
		deviceId: deviceId,
		iotMmsDest: iotMmsDestName
    });
  	mainPage.addContent(colorPicker);
    
    var chart = createIOTTableChart({
		messageId: msgIdTemp,
		deviceId: deviceId,
		iotMmsDest: iotMmsDestName,
		updateIntervalSec: 15,
		tableField: "C_TEMP"
    });
  	mainPage.addContent(chart);
  	
    startThingButtonWatch({
		messageId: msgIdButton,
		deviceId: deviceId,
		iotMmsDest: iotMmsDestName,    	
    	onClick: function(msgCount) {sap.ui.commons.MessageBox.alert(msgCount + " new messages");}
    });
  	 
 
    var app = new sap.m.App("myApp", {  initialPage : idPageMain  });
  	app.addPage(mainPage);
    app.setBackgroundRepeat(true);
    app.placeAt("content");
}

buildUI();
